function recruitment(){
  const collapse=document.getElementById('first')
  collapse.classList.toggle('toggle')
}
function leaves(){
  const collapse=document.getElementById('second')
  collapse.classList.toggle('toggle')
}
function reports(){
  const collapse=document.getElementById('third')
  collapse.classList.toggle('toggle')
}
function collapse(){
  const collapse=document.getElementById('collapse')
  collapse.classList.toggle('to-collapse')
}