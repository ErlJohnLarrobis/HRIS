function recruitment(){
  const fcollapse=document.getElementById('first')
  fcollapse.classList.toggle('toggle')
}
function leaves(){
  const scollapse=document.getElementById('second')
  scollapse.classList.toggle('toggle')
}
function reports(){
  const tcollapse=document.getElementById('third')
  tcollapse.classList.toggle('toggle')
}
function collapse(){
  const collapse=document.getElementById('collapse')
  collapse.classList.toggle('to-collapse')
}
function uncollapse(){
  const uncollapse=document.getElementById('collapse')
  uncollapse.classList.toggle('to-collapse')
}